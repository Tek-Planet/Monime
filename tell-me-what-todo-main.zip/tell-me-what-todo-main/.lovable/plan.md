
# Fix Admin Login Onboarding Redirect Issue

## Problem Summary
When logging into the admin account, the user is being redirected to the onboarding screen instead of the admin panel or dashboard. This issue is caused by **build errors** in `LanguageContext.tsx` that prevent the application from running correctly.

## Root Cause Analysis

### Primary Issue: Build Errors in LanguageContext.tsx
The application has **duplicate translation keys** in the translations object, causing TypeScript build errors:
- Error: `An object literal cannot have multiple properties with the same name`
- Affected lines: Multiple locations across English, Krio, French, and Arabic translation sections

The duplicate keys include:
- `onboarding.complete` (appears twice)
- `onboarding.completeDesc` (appears twice)
- `onboarding.setupComplete` (appears twice)
- `onboarding.profileComplete` (appears twice)
- `onboarding.setupFailed` (appears twice)
- `setup.title`, `setup.notAvailable`, `setup.creating`, `setup.becomeAdmin` (duplicates)
- `privacy.lastUpdated`, `privacy.dataSecurity`, `privacy.cookies`, `privacy.changes`, `privacy.contact` (duplicates)
- And many more across all 4 language sections

### Why This Affects Admin Login
When the build fails due to these TypeScript errors, the application cannot properly:
1. Initialize the LanguageContext provider
2. Load the ProtectedRoute component
3. Execute the admin type checking logic

Even though the database shows:
- Admin user exists: `user_id: 07ce1f48-3792-4902-ad5b-e81f9e52d5b7`
- Admin role is properly set in `user_roles` table (role: `admin`)
- User has a profile and business already created

The app cannot reach the logic that would recognize the admin and bypass onboarding.

## Solution

### Step 1: Fix Duplicate Translation Keys in LanguageContext.tsx
Remove all duplicate translation keys from each language section (en, krio, fr, ar). The duplicates need to be consolidated, keeping only one instance of each key.

**Keys to deduplicate (consolidated list):**

**English (en) section:**
- Lines ~755-790: auth and onboarding keys that are duplicated later in the section
- Lines ~1265-1415: Additional audit keys that duplicate earlier definitions
- Keys: `onboarding.*`, `setup.*`, `privacy.*` duplicates

**Krio, French, Arabic sections:**
- Similar patterns of duplicate keys need to be removed

### Step 2: Verify Protected Route Logic (Already Correct)
The existing ProtectedRoute logic is correct and will work once the build succeeds:
```typescript
// Admins don't need to complete onboarding
const isAdmin = adminType === 'system_admin' || adminType === 'ngo_admin'

// Only redirect admins to admin panel if they don't have an associated business
if (isAdmin && !business && location.pathname === '/') {
  return <Navigate to="/admin" replace />
}

// If user needs onboarding - ONLY applies to non-admins
if (!isAdmin && needsOnboarding && location.pathname !== '/onboarding') {
  return <Navigate to="/onboarding" replace />
}
```

Since your admin user (`abiolaolalekan39@gmail.com`) has:
- An admin role in `user_roles` table
- A profile record
- A business record ("AbiTek Technologies")

After the build errors are fixed, they should be taken directly to the dashboard (since they have a business) rather than the admin panel or onboarding page.

## Implementation Steps

1. **Audit English translations (lines 1-1416)** - Remove duplicate keys, keeping the first or most complete definition
2. **Audit Krio translations (lines ~1417-2400)** - Remove corresponding duplicates
3. **Audit French translations (lines ~2400-3500)** - Remove corresponding duplicates  
4. **Audit Arabic translations (lines ~3500-4620)** - Remove corresponding duplicates

## Expected Outcome
After fixing the duplicate keys:
- The application will build successfully
- Admin users will be properly recognized by the `useAdminType` hook
- The ProtectedRoute will correctly skip onboarding for admins
- Your admin account will go directly to the dashboard (since you have a business)

## Technical Details

The specific duplicate keys to remove or consolidate:

| Key | First Location | Duplicate Location |
|-----|---------------|-------------------|
| `onboarding.title` | ~764 | Later in audit section |
| `onboarding.complete` | ~773 | Later in audit section |
| `setup.title` | ~948 | ~1407 |
| `setup.notAvailable` | ~949 | ~1405 |
| `privacy.lastUpdated` | ~937 | ~1350 |
| `privacy.dataSecurity` | ~940 | ~1338 |

The same pattern repeats in each language section (Krio, French, Arabic), so all four sections need to be cleaned up.
